'''
Python imports Examples

@author: Puneetha B M
'''

import math
import re
import random
from functools import reduce
from datetime import datetime
from itertools import chain